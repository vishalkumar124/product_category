const mysql = require("mysql")
const con = mysql.createConnection({

    host:"localhost",
    port: 3307,
    user:"root",
    password:"",
    database:"project_cat"
});

con.connect((err) => {
    if (err) throw err;
    console.log("hurrah! successful Connection");
});

module.exports.con = con;