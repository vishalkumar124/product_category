const path = require('path');
const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const app = express();
const port = 3004
const mysql = require("./connection").con;
    // configuration
    app.set('view engine', 'ejs');
    app.set("views", "./src")
    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({ extended: false }));

app.use(express.static(__dirname + "/public"))

// Routing
app.get("/", (req, res) => {
    res.render("index")
});
app.get("/add", (req, res) => {
    res.render("add")

});
app.get("/search", (req, res) => {
    res.render("search")

});
app.get("/update", (req, res) => {
    res.render("update")

});

app.get("/delete", (req, res) => {
    res.render("delete")

});
app.get("/view", (req, res) => {
    let sql = "select * from cat_table where parent_id!=0";
    let query = mysql.query(sql, (err, rows) => {
        if(err) throw err;
        res.render('view', {
            products : rows
        });
    });

});
app.get("/viewcat", (req, res) => {
    let sql = "select * from cat_table where parent_id=0";
    let query = mysql.query(sql, (err, rows) => {
        if(err) throw err;
        res.render('viewcat', {
            cats : rows
        });
    });

});
app.get('/delete/:userId',(req, res) => {
    const userId = req.params.userId;
    let sql = `DELETE from cat_table where id = ${userId}`;
    let query = mysql.query(sql,(err, result) => {
        if(err) throw err;
        res.redirect('/view');
    });
});
app.get('/viewlist/:userId',(req, res) => {
    const userId = req.params.userId;
    let sql = `select * from cat_table where parent_id = ${userId}`;
    let query = mysql.query(sql,(err, result) => {
        if(err) throw err;
        res.render('viewlist', {
            items : result
        });
    });

});









//Create Server
app.listen(port, (err) => {
    if (err)
        throw err
    else
        console.log("Server is running at port %d:", port);
});